# 说明

## 二进制安装

二进制安装集群，核心组件的监控需要创建endpoint.

```bash
kubectl apply -f /etc/kubernetes/manifests/core-server-ep.yml
kubectl apply -f /etc/kubernetes/manifests/kubelet-ep.yml
```

## 创建服务

先创建 ns 再创建 operator，最后创建所有.

```bash
sed -e "s/nfs-storage-class/alicloud-disk-available-efg/g" -i prometheus/prometheus-main.yml

kubectl apply -f /etc/ansible/manifests/monitoring/monitoring-ns.yml
kubectl apply -f /etc/ansible/manifests/monitoring/operator
kubectl apply -R -f /etc/ansible/manifests/monitoring/
```

## operator

参考url: https://raw.githubusercontent.com/coreos/prometheus-operator/master/bundle.yaml

## 联邦集群需要配置 params

docker run  --name fed -d -p 9091:9090 -e TZ="Asia/Shanghai" -v $PWD/federate.yml:/etc/prometheus/prometheus.yml quay.azk8s.cn/prometheus/prometheus:v2.15.2

## 问题总结

- kubele采集指标报401认证失败
  https://github.com/coreos/prometheus-operator/issues/926
  最优方式是修改为http方式采集，http-metric也是只读端口（10255），https-metric读写端口（10250）

```yaml
port: http-metrics
scheme: http
```

- metallb 下创建的service注意参数配置， externalTrafficPolicy: Local(加上后本机无法访问)
